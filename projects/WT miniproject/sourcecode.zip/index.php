<!DOCTYPE html>
<html>
<title>Home Page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link href="css/main.css" rel="stylesheet" />
<link href="css/animate.css" rel="stylesheet" />

	<body>

		<div class="container">

			<br>
			<div class = "animated fadeInDownBig">
                <h2 ><font color='Blue'><b> Welcome to  College Forum Manager</b></font> </h2>
                <h2><font color='Blue'><b> What would you like to do ?</b></font> </h2>
			</div>
					<br>
					<hr>
            <label class = "options animated fadeInRight"><font color='blue'>Have an existing account ?</font></label><br><br>
			<a href = "login.php" class ="btn btn-default animated fadeIn">Log in</a>
					<br>
					<hr>
					<br>
            //<label class ="options animated fadeInRight" ><font color='blue'>Don't have an account yet ?</font></label><br><br>
			//<a href = "create.php" class = "btn btn-default animated fadeIn">Create One</a>

	</div>
	</body>
</html>





















<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>index</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="Style2.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	color: #FFFF99;
}
.style12 {
	color: #FF00FF;
	font-size: 18px;
}
.style14 {
	color: #663333;
	font-size: 14px;
}
.style15 {
	color: #660033;
	font-size: 14px;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
}
body {
	margin-left: 1cm;
	margin-top: 0.5cm;
}
.style19 {
	color: #660000;
	font-size: 20px;
}
-->
    </style>
    </head>
</html>