
<html>
<head>
<title>Login Page</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
<link href="css/animate.css" rel="stylesheet" />
<link href="css/main.css" rel="stylesheet" />
<body>
	<div class="container">
        <h3 class = "animated fadeInDownBig"> <font color='white'>Login page</font></h3>
		<hr>
		<div class="form-group animated fadeIn">
		<form action = "profile.php" method = "POST" class = "form-inline">
            <label><font color='white'>USN</font></label>
			<input type ="text" name ="email" value = "">

            <label><font color='white'>Password</font></label>
			<input type ="password" name ="password" value = "">
			<input type ="submit" class = "btn btn-default" value ="login">
			<br>
			<br>
			<hr>
			<button class = "btn btn-default" formaction= "index.php">Back</button>
		</form>
	    </div>
    </div>
</body>
</html>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>login</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="style.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	color: #FFFF99;
}
.style12 {
	color: #FF00FF;
	font-size: 18px;
}
.style14 {
	color: #663333;
	font-size: 14px;
}
.style15 {
	color: #660033;
	font-size: 14px;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
}
body {
	margin-left: 1cm;
	margin-top: 0.5cm;
}
.style19 {
	color: #660000;
	font-size: 20px;
}
-->
    </style>
    </head>
</html>